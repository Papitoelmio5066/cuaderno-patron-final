
package diarte.gabriel.examen;

public class DiarteGabrielExamen {

    public static void main(String[] args) {
        long tiempo = System.currentTimeMillis();
        
        //V1
     
        //Cliente cliente1 = new Cliente("Paco", new int[] {1,3,5});
        //Cliente cliente2 = new Cliente("Jose", new int[] {3,4,4,1});

        //Cajera cajera1 = new Cajera("Cajera 1");
        //Cajera cajera2 = new Cajera("Cajera 1");
        
        //cajera1.procesarCompra(cliente1, tiempo);
        //cajera1.procesarCompra(cliente2, tiempo);
        
        
        //V2
        Cliente cliente1 = new Cliente("Paco", new int[] {1,3,5});
        Cliente cliente2 = new Cliente("Jose", new int[] {3,4,4,1});
        
        Cajera cajera1 = new Cajera("Cajera 1", tiempo, cliente1);
        Cajera cajera2 = new Cajera("Cajera 2", tiempo, cliente2);
        
        cajera1.start();
        cajera2.start();
        
        //En el examen de dual no se si era necesario hacerlo
        //con varios clientes y varias cajeras, de todas formas
        //como creo que asi esta mas completo lo he realizado con 
        //varios clientes y varias cajeras
        
        //Tambien esta comentado lo que se usaria si lo quieres
        //hacer sin utilizar Threads
    }
    
}
