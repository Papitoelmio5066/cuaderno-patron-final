public class Filosofo extends Thread {
    private Mesa mesa;
    private int comensal;
    private int indiceComensal;
    private Buffer buffer;

    public Filosofo(Buffer buffer, Mesa m, int comensal) {
        this.mesa = m;
        this.comensal = comensal;
        this.indiceComensal = comensal - 1;
        this.buffer = buffer;
    }
    

    public Mesa getMesa() {
        return mesa;
    }


    public void setMesa(Mesa mesa) {
        this.mesa = mesa;
    }


    public int getComensal() {
        return comensal;
    }


    public void setComensal(int comensal) {
        this.comensal = comensal;
    }


    public int getIndiceComensal() {
        return indiceComensal;
    }


    public void setIndiceComensal(int indiceComensal) {
        this.indiceComensal = indiceComensal;
    }


    @Override
    public void run() {
        /* ¿Tiene aspecto de patrón? */
        while (true) {
            buffer.sender(this);
            /* this.pensando();
            this.mesa.cogerTenedores(indiceComensal);
            int indiceVino = this.mesa.cogerVino();
            this.comiendo();
            this.bebiendo();

            System.out.println("Filosofo->" + comensal + " deja de comer, tenedores libres "
                    + (this.mesa.tenedorIzquierda(indiceComensal) + 1) + ", "
                    + (this.mesa.tenedorDerecha(indiceComensal) + 1) + " .\n " + comensal
                    + " deja de beber , vino libre  " + indiceVino);
            this.mesa.dejarVino(indiceVino);

            this.mesa.dejarTenedores(indiceComensal); */

        }

    }

    public void comiendo() {
        System.out.println("Filósofo->" + comensal + " esta Comiendo. ");
        try {
            sleep((long) (Math.random() * 4000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void pensando() {

        System.out.println("Filosofo->" + comensal + " Pensando. ");
        try {
            sleep((long) (Math.random() * 4000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    public void bebiendo() {

        System.out.println("Filosofo->" + comensal + " Bebiendo. ");
        try {
            sleep((long) (Math.random() * 4000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

}
