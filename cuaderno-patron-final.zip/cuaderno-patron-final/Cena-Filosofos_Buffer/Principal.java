public class Principal {
    public static void main(String[] args) {
        Buffer buffer = new Buffer();
        Thread receiver = new Thread(new Receiver(buffer));
        Mesa mesa = new Mesa(5, 2);
        /* Filosofo f1 = new Filosofo(buffer, mesa, 1);
        Filosofo f2 = new Filosofo(buffer, mesa, 2);
        Filosofo f3 = new Filosofo(buffer, mesa, 3);
        Filosofo f4 = new Filosofo(buffer, mesa, 4);
        Filosofo f5 = new Filosofo(buffer, mesa, 5);
        f1.start();
        f2.start();
        f3.start();
        f4.start();
        f5.start(); */
        receiver.start();
        for (int i = 1; i <= 5; i++) {
            Filosofo f = new Filosofo(buffer, mesa, i);
            //receiver.start();
            f.start();
            
        }

    }
}
