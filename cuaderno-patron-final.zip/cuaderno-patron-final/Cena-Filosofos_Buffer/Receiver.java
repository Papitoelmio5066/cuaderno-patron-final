import java.util.concurrent.ThreadLocalRandom;

public class Receiver implements Runnable {
    private Buffer buffer;
    // private Cerveza cerveza;

    // standard constructors
    public Receiver(Buffer buffer) {
        this.buffer = buffer;
    }

    public void run() {
        for (Filosofo receivedMessage = buffer.receive(); !"End".equals(receivedMessage); receivedMessage = buffer
                .receive()) {

            receivedMessage.pensando();
            receivedMessage.getMesa().cogerTenedores(receivedMessage.getIndiceComensal());
            int indiceVino = receivedMessage.getMesa().cogerVino();
            receivedMessage.comiendo();
            receivedMessage.bebiendo();
            System.out.println("Filosofo->" + receivedMessage.getComensal() + " deja de comer, tenedores libres "
                    + (receivedMessage.getMesa().tenedorIzquierda(receivedMessage.getIndiceComensal()) + 1) + ", "
                    + (receivedMessage.getMesa().tenedorDerecha(receivedMessage.getIndiceComensal()) + 1) + " .\n "
                    + receivedMessage.getComensal()
                    + " deja de beber , vino libre  " + indiceVino);

            receivedMessage.getMesa().dejarVino(indiceVino);
            receivedMessage.getMesa().dejarTenedores(receivedMessage.getIndiceComensal());
            // Thread.sleep() to mimic heavy server-side processing
            try {
                Thread.sleep(ThreadLocalRandom.current().nextInt(1000, 5000));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Thread Interrupted");
            }
        }
    }
}